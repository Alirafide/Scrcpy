package com.example.tvremote

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import dadb.AdbKeyPair
import dadb.Dadb
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val io = Executors.newSingleThreadExecutor()
    private var dadb: Dadb? = null
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun say(msg: String) = runOnUiThread { status.text = msg }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("tv", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }

        // --- الاتصال ---
        val ip = EditText(this).apply {
            hint = "IP التلفاز  مثال: 192.168.1.50"
            setText(prefs.getString("ip", ""))
            setSingleLine()
        }
        root.addView(ip)

        val connect = Button(this).apply { text = "اتصال" }
        connect.setOnClickListener {
            val host = ip.text.toString().trim()
            prefs.edit().putString("ip", host).apply()
            connect(host)
        }
        root.addView(connect)

        status = TextView(this).apply {
            text = "غير متصل"
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(status)

        // --- D-Pad ---
        val pad = GridLayout(this).apply { columnCount = 3; rowCount = 3 }
        fun add(label: String, row: Int, col: Int, key: Int) {
            val b = key(label, key)
            pad.addView(b, GridLayout.LayoutParams(GridLayout.spec(row), GridLayout.spec(col)).apply {
                width = dp(96); height = dp(72); setMargins(dp(4), dp(4), dp(4), dp(4))
            })
        }
        add("▲", 0, 1, 19)
        add("◀", 1, 0, 21)
        add("OK", 1, 1, 23)
        add("▶", 1, 2, 22)
        add("▼", 2, 1, 20)
        val padWrap = LinearLayout(this).apply { gravity = Gravity.CENTER }
        padWrap.addView(pad)
        root.addView(padWrap)

        // --- أزرار عامة ---
        root.addView(row(key("Back", 4), key("Home", 3), key("Menu", 82)))
        root.addView(row(key("Vol −", 25), key("Mute", 164), key("Vol +", 24)))
        root.addView(row(key("⏮", 88), key("⏯", 85), key("⏭", 87)))
        root.addView(row(key("Power", 26), key("Apps", 187)))

        // --- إرسال نص ---
        val txt = EditText(this).apply { hint = "نص للإرسال إلى التلفاز"; setSingleLine() }
        root.addView(txt)
        val send = Button(this).apply { text = "إرسال النص" }
        send.setOnClickListener {
            val t = txt.text.toString().replace("'", "").replace(" ", "%s")
            if (t.isNotEmpty()) shell("input text '$t'")
        }
        root.addView(send)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun key(label: String, code: Int) = Button(this).apply {
        text = label
        setOnClickListener { shell("input keyevent $code") }
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach {
            addView(it, LinearLayout.LayoutParams(0, dp(60), 1f))
        }
    }

    private fun connect(host: String) {
        if (host.isEmpty()) { say("أدخل IP التلفاز"); return }
        say("جاري الاتصال… اقبل الطلب على شاشة التلفاز")
        io.execute {
            try {
                dadb?.close()
                val priv = File(filesDir, "adbkey")
                val pub = File(filesDir, "adbkey.pub")
                if (!priv.exists()) AdbKeyPair.generate(priv, pub)
                val kp = AdbKeyPair.read(priv, pub)
                val d = Dadb.create(host, 5555, kp)
                val model = d.shell("getprop ro.product.model").output.trim()
                dadb = d
                say("متصل ✔  $model")
            } catch (e: Exception) {
                dadb = null
                say("فشل الاتصال: ${e.message}")
            }
        }
    }

    private fun shell(cmd: String) {
        val d = dadb
        if (d == null) { say("غير متصل"); return }
        io.execute {
            try { d.shell(cmd) } catch (e: Exception) {
                dadb = null
                say("انقطع الاتصال: ${e.message}")
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        io.execute { try { dadb?.close() } catch (_: Exception) {} }
    }
}
